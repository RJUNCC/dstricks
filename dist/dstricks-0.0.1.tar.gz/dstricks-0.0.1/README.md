# dstricks

A package full of data science functions I learned along the way.
