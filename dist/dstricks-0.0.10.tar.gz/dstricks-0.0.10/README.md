# dstricks

[Github Link](https://github.com/RJUNCC/dstricks/tree/main?tab=readme-ov-file)

[Pypi Link](https://pypi.org/project/dstricks/)

A package full of data science functions I learned along the way.
These should include modeling, visualization, statistics, etc.
This is used to make workflow faster and have already available functions.
This probably won't be able to cover all of the things that you need but this is mainly based on what I do.
